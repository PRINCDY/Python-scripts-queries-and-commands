# Security Policy

## Supported Versions

Any issues reported should be applicable to the latest development version on the default branch of this repository.

## Reporting a Vulnerability

Security vulnerabilities should be reported privately through GitHub.
