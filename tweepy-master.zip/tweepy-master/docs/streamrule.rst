.. _streamrule:

.. currentmodule:: tweepy

``StreamRule``
==============
.. autoclass:: StreamRule
   :class-doc-from: class
