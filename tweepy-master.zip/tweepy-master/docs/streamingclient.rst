.. _streamingclient_reference:

.. currentmodule:: tweepy

************************
:class:`StreamingClient`
************************

.. autoclass:: StreamingClient
   :members:
   :inherited-members:
   :member-order: bysource
