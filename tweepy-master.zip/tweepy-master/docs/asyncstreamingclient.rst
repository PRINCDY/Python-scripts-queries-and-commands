.. _asyncstreamingclient_reference:

.. currentmodule:: tweepy.asynchronous

*****************************
:class:`AsyncStreamingClient`
*****************************

.. autoclass:: AsyncStreamingClient
   :members:
   :inherited-members:
   :member-order: bysource
